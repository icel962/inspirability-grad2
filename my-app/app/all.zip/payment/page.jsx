"use client";
import "./payment.css";
import Navbar from "../component/Navbar";
import Footer from "../component/Footer";
import { useState } from "react";

export default function PaymentPage() {
  const [method, setMethod] = useState("card");

  const handleContinue = () => {
    alert("Continue clicked");
  };

  const handlePay = () => {
    alert("Payment Successful ✅");
  };

  return (
    <>
     

      <section className="payment">

        {/* ✅ TITLE (FIXED POSITION) */}
        <h2 className="title">Select your card</h2>

        {/* ✅ PAYMENT METHODS */}
        <div className="card-types">
          <div
            className={`type ${method === "card" ? "active" : ""}`}
            onClick={() => setMethod("card")}
          >
            💳
          </div>

          <div
            className={`type ${method === "paypal" ? "active" : ""}`}
            onClick={() => setMethod("paypal")}
          >
            PayPal
          </div>

          <div
            className={`type ${method === "apple" ? "active" : ""}`}
            onClick={() => setMethod("apple")}
          >
            Pay
          </div>
        </div>

        {/* ✅ CONDITIONAL UI */}
        {method === "card" && (
          <>
            {/* CARDS */}
            <div className="cards">
              <div className="credit-card red">
                <div className="card-top">
                  <span>🏦 FYI BANK</span>
                  <span>CREDIT</span>
                </div>

                <h3 className="number">0000 2363 8364 8269</h3>

                <div className="card-bottom">
                  <div>
                    <small>VALID THRU</small>
                    <p>5/23</p>
                  </div>

                  <div>
                    <small>CVV</small>
                    <p>633</p>
                  </div>
                </div>

                <div className="card-name">Okechukwu Ozioma</div>
                <div className="brand">VISA</div>
              </div>

              <div className="credit-card blue">
                <div className="card-top">
                  <span>🏦 FYI BANK</span>
                  <span>CREDIT</span>
                </div>

                <h3 className="number">0000 2363 8364 8269</h3>

                <div className="card-bottom">
                  <div>
                    <small>VALID THRU</small>
                    <p>5/23</p>
                  </div>

                  <div>
                    <small>CVV</small>
                    <p>633</p>
                  </div>
                </div>

                <div className="card-name">Okechukwu Ozioma</div>
                <div className="brand">MasterCard</div>
              </div>
            </div>

            {/* FORM + SUMMARY */}
            <div className="content">
              <div className="form">
                <h3>Enter card details</h3>

                <input placeholder="Card name" />
                <input placeholder="Card number" />

                <div className="row">
                  <input placeholder="MM / YY" />
                  <input placeholder="CVV" />
                </div>

                <div className="checkbox">
                  <label>
                    <input type="checkbox" /> I agree to Terms
                  </label>

                  <label>
                    <input type="checkbox" /> Save card details
                  </label>
                </div>
              </div>

              <div className="summary">
                <div className="line">
                  <span>Custom bag</span>
                  <span>$50</span>
                </div>

                <div className="line">
                  <span>Delivery charge</span>
                  <span>$5</span>
                </div>

                <hr />

                <div className="total">
                  <span>Total Amount</span>
                  <span>$55</span>
                </div>

                <button className="btn" onClick={handleContinue}>
                  CONTINUE
                </button>

                <button className="btn primary" onClick={handlePay}>
                  PAY NOW
                </button>
              </div>
            </div>
          </>
        )}

        {/* PAYPAL */}
        {method === "paypal" && (
          <div className="method-box">
            <h3>Pay with PayPal</h3>
            <button className="btn primary" onClick={handlePay}>
              Pay Now
            </button>
          </div>
        )}

        {/* APPLE PAY */}
        {method === "apple" && (
          <div className="method-box">
            <h3>Pay with Apple Pay</h3>
            <button className="btn primary" onClick={handlePay}>
              Pay Now
            </button>
          </div>
        )}

      </section>

  
    </>
  );
}